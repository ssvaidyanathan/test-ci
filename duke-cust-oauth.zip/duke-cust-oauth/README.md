```
    mvn clean install \
    -P{profile} \
    -Dorg={org} \
    -env={env} \
    -Dusername={username} \
    -Dpassword={password} \
    -Dapigee.config.dir=target/resources/edge \
    -Dapigee.config.options=create \
    -Dapigee.config.exportDir=./target/test/integration
    
```
