/* jslint node: true */
'use strict';

var config = require('../../test-config.json');
var apps = require('../../devAppKeys.json');

var creds = {};

function getCreds(appName, productName){
	for(var app in apps){
  	if(apps[app].name === appName){
    	var credentials = apps[app].credentials;
      for(var credential in credentials){
      	var products = credentials[credential].apiProducts;
        for(var product in products){
          if(products[product].apiproduct === productName){
            creds.consumerKey = credentials[credential].consumerKey;
            creds.consumerSecret = credentials[credential].consumerSecret;
          }
        }
      }
    }
  }
}

module.exports = function() {

	this.registerHandler("BeforeFeatures", function(event, next) {
    	getCreds(config.app, config.product);
      	return next();
  	});

  this.Given(/^I set the client authorization in header$/, function (callback) {
        this.apickli.addHttpBasicAuthorizationHeader(creds.consumerKey, creds.consumerSecret);
        callback();
    });

  this.Given(/^I set body to refresh_token from the global variable$/, function (bodyValue, callback) {
        var bodyValue = "grant_type=refresh_token&refresh_token="+this.apickli.getGlobalVariable("refresh_token");
        this.apickli.setRequestBody(bodyValue);
        callback();
    });
};
