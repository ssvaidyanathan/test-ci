/* jshint node:true */
'use strict';

var apickli = require('apickli');
var config = require('../../test-config.json');

console.log('namOAuthApi api: [' + config.domain + ', ' + config.basepath + ']');

module.exports = function() {

    this.registerHandler("BeforeFeatures", function(event, next) {
      	return next();
  	});

	// cleanup before every scenario
	this.Before(function(scenario, callback) {
		this.apickli = new apickli.Apickli('https',
										   config.domain + config.basepath,
										   './test/integration/features/fixtures/');
		callback();
	});

  this.registerHandler("AfterFeatures", function(event, next) {
      	return next();
  });
  
};
